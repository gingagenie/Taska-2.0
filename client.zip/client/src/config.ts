export const APP_NAME = "Taska";
export const ORG_NAME = "Taska Demo Org";
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";
export const DEMO_MODE = false;